//
//  Good.m
//  
//
//  Created by Crystal on 16/8/31.
//
//

#import "Good.h"

@implementation Good

// Insert code here to add functionality to your managed object subclass

@end
