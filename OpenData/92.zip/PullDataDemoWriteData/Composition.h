//
//  Composition.h
//  
//
//  Created by Crystal on 16/8/31.
//
//

#import <Foundation/Foundation.h>
#import <CoreData/CoreData.h>

@class Product;

NS_ASSUME_NONNULL_BEGIN

@interface Composition : NSManagedObject

// Insert code here to declare functionality of your managed object subclass

@end

NS_ASSUME_NONNULL_END

#import "Composition+CoreDataProperties.h"
