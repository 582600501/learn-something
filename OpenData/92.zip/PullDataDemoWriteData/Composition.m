//
//  Composition.m
//  
//
//  Created by Crystal on 16/8/31.
//
//

#import "Composition.h"
#import "Product.h"

@implementation Composition

// Insert code here to add functionality to your managed object subclass

@end
