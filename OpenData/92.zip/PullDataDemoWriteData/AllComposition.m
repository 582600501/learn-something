//
//  AllComposition.m
//  
//
//  Created by Crystal on 16/8/31.
//
//

#import "AllComposition.h"

@implementation AllComposition

// Insert code here to add functionality to your managed object subclass

@end
