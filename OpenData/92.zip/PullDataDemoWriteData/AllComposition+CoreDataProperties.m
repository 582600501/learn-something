//
//  AllComposition+CoreDataProperties.m
//  
//
//  Created by Crystal on 16/8/31.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "AllComposition+CoreDataProperties.h"

@implementation AllComposition (CoreDataProperties)

@dynamic cas_num;
@dynamic ename;
@dynamic name;
@dynamic other_name;
@dynamic safety;
@dynamic summary;
@dynamic used;

@end
