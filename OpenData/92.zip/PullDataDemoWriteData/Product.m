//
//  Product.m
//  
//
//  Created by Crystal on 16/8/31.
//
//

#import "Product.h"
#import "Composition.h"

@implementation Product

// Insert code here to add functionality to your managed object subclass

@end
