//
//  Composition+CoreDataProperties.m
//  
//
//  Created by Crystal on 16/9/1.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Composition+CoreDataProperties.h"

@implementation Composition (CoreDataProperties)

@dynamic name;
@dynamic safety;
@dynamic used;
@dynamic compositionId;
@dynamic sort;
@dynamic product;

@end
