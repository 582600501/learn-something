//
//  Product+CoreDataProperties.m
//  
//
//  Created by Crystal on 16/8/31.
//
//
//  Choose "Create NSManagedObject Subclass…" from the Core Data editor menu
//  to delete and recreate this implementation file for your updated model.
//

#import "Product+CoreDataProperties.h"

@implementation Product (CoreDataProperties)

@dynamic brand;
@dynamic capacity;
@dynamic cateName;
@dynamic company;
@dynamic country;
@dynamic doyenComment;
@dynamic name;
@dynamic other_name;
@dynamic price;
@dynamic address_china;
@dynamic approval;
@dynamic efficacy;
@dynamic composition;

@end
