/*
 Copyright (C) 2017 Apple Inc. All Rights Reserved.
 See LICENSE.txt for this sample’s licensing information
 
 Abstract:
 A basic UIApplication delegate which sets up the application.
 */

@import UIKit;

@interface PhotoMapAppDelegate : NSObject <UIApplicationDelegate>

@end
