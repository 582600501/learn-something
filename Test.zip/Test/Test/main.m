//
//  main.m
//  Test
//
//  Created by Crystal on 17/2/14.
//  Copyright © 2017年 crystal. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
