//
//  TestViewController.m
//  Test
//
//  Created by Crystal on 17/3/9.
//  Copyright © 2017年 crystal. All rights reserved.
//

#import "TestViewController.h"


@interface TestViewController ()<UITableViewDataSource, UITableViewDelegate>
@property (nonatomic, strong) UITableView *tableView;
@property (nonatomic, strong) NSMutableArray *dataSource;
@end

@implementation TestViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view setBackgroundColor:[UIColor yellowColor]];
    [self setupRightButton];
    [self setupDataSource];
    [self setupTableView];
    [self.view addSubview:self.tableView];
}

#pragma mark pravite methods
- (void)setupDataSource {
    self.dataSource = [NSMutableArray array];
    for(int i = 0; i < 5; i++) {
        [self.dataSource addObject:[NSNumber numberWithInt:i]];
    }
}

- (void)setupTableView {
    self.tableView = [[UITableView alloc] initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
}

- (void)setupRightButton {
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"增加" style:UIBarButtonItemStylePlain target:self action:@selector(addRow)];
    self.navigationItem.rightBarButtonItem = rightItem;
}

- (void)addRow {
    //关键！！在调用insertRowsAtIndexPaths方法前得先把数据源更新了
    [self.dataSource addObject:@(1)];
    [self.tableView beginUpdates];
    NSMutableArray *indexPaths = [NSMutableArray array];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:self.dataSource.count-1 inSection:0];
    [indexPaths addObject:indexPath];
    [self.tableView insertRowsAtIndexPaths:indexPaths withRowAnimation:UITableViewRowAnimationNone];
    [self.tableView endUpdates];
}

#pragma mark UITableViewDataSource methods
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return  [self.dataSource count];
}

#pragma mark UITableViewDelegate methods
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *identifier = @"identifier";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
        cell.backgroundColor = [UIColor redColor];
    }
    
    return cell;
}

@end
