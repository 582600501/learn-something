//
//  ViewController.h
//  ChatWithUIImageResizingMode
//
//  Created by apple on 17/4/25.
//  Copyright © 2017年 ss. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

