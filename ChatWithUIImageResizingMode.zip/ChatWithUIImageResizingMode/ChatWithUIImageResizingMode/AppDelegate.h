//
//  AppDelegate.h
//  ChatWithUIImageResizingMode
//
//  Created by apple on 17/4/25.
//  Copyright © 2017年 ss. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

