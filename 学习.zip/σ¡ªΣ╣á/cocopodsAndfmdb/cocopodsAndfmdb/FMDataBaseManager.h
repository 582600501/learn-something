//
//  FMDataBaseManager.h
//  Life
//
//  Created by ss on 15/10/28.
//  Copyright (c) 2015年 ss. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDatabase.h"
#import "Migration.h"
//#import "TopicModel.h"
//#import "ProductCollectModel.h"
@interface FMDataBaseManager : NSObject
{
    FMDatabase * _dataBase;
    NSString * _DBPath;
    
}
+ (instancetype)shareDataBaseManager;
- (instancetype)init;

-(FMResultSet *)productSelectAll;

-(FMResultSet *)productSelectWithType:(NSString *)type;
-(void)insertIntoHistory:(NSString * )callnumber calltime:(NSString *)calltime;
-(FMResultSet *)selectAllFromtest;
-(void)updatate;
-(void)deletetestWithCallNumber:(NSString *)callNumber name:(NSString *)name;
-(void)deletHistoryWithUserName:(NSString *)username number:(NSString *)callnumber time:(NSString *)time;
-(void)addNewField;
@end
