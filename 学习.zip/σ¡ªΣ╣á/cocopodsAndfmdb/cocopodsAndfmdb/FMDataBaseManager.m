//
//  FMDataBaseManager.m
//  Life
//
//  Created by ss on 15/10/28.
//  Copyright (c) 2015年 ss. All rights reserved.
//

#import "FMDataBaseManager.h"

@implementation FMDataBaseManager
+ (instancetype)shareDataBaseManager{

    static FMDataBaseManager * manager;
    if (manager==nil) {
        manager=[[FMDataBaseManager alloc]init];
    }
    
    return manager;
}


//@property (nonatomic,copy)NSString * category;
//@property (nonatomic,copy)NSString * comments;
//@property (nonatomic,copy)NSString * desc;
//@property (nonatomic,copy)NSString * ID;
//@property (nonatomic,copy)NSString * iscomments;
//@property (nonatomic,copy)NSString * islike;
//@property (nonatomic,copy)NSString * item_id;
//@property (nonatomic,copy)NSString * likes;
//@property (nonatomic,copy)NSString * number;
//@property (nonatomic,copy)NSString * platform;
//@property (nonatomic,copy)NSString * price;
//@property (nonatomic,copy)NSString * share_url;
//@property (nonatomic,copy)NSString * title;
//@property (nonatomic,copy)NSString * topic_id;
//@property (nonatomic,copy)NSString * type;
//@property (nonatomic,copy)NSString * url;
//@property NSArray * pic;

- (instancetype)init{
    if ([super init]) {
        
        NSString * sandBoxPath = [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/test.db"];
        NSLog(@"------%@",sandBoxPath);
        _DBPath=sandBoxPath;
        _dataBase=[[FMDatabase alloc]initWithPath:sandBoxPath];
        if ([_dataBase open]) {
            NSLog(@"数据库打开");
        }
        
        NSString * createSql=@"create table if not exists test(id integer primary key autoincrement,callnumber varchar(256))";
        
        if ([_dataBase executeUpdate:createSql]) {
            NSLog(@"建表成功");
        }

        
    }
    return self;
}

-(void)deletHistoryWithUserName:(NSString *)username number:(NSString *)callnumber time:(NSString *)time{
   NSString * deletSql=@"delete from history where time=?";
    if ([_dataBase executeUpdate:deletSql,username,callnumber,time ]) {
        NSLog(@"History删除成功");
    }
}
-(void)deletetestWithCallNumber:(NSString *)callNumber name:(NSString *)name;
{
    NSString * deletSql=@"delete from test where callnumber=? and name=?";
    if ([_dataBase executeUpdate:deletSql,callNumber,name]) {
        NSLog(@"test删除成功");
    }
    
}
-(void)insertIntoHistory:(NSString * )callnumber calltime:(NSString *)calltime;
{
   NSString * insertSql=@"insert into test(callnumber,name) values(?,?)";
    if ([_dataBase executeUpdate:insertSql,callnumber,calltime]) {
        NSLog(@"test插入成功");
    }

}


-(void)addNewField{
    FMDBMigrationManager * manager=[FMDBMigrationManager managerWithDatabaseAtPath:_DBPath migrationsBundle:[NSBundle mainBundle]];
    Migration * migration_1=[[Migration alloc]initWithName:@"新增字段name" addVersion:1 andExecuteUpdateArray:@[@"alter table test add name text"]];
    [manager addMigration:migration_1];
    
    BOOL resultState=NO;
    NSError * error=nil;
    if (!manager.hasMigrationsTable) {
        resultState=[manager createMigrationsTable:&error];
    }
    
    resultState=[manager migrateDatabaseToVersion:UINT64_MAX progress:nil error:&error];
    
    //[self updatate];
    
}

-(FMResultSet *)selectAllFromtest{
    NSString * selectSql=@"select * from test";
    FMResultSet * set=[_dataBase executeQuery:selectSql];
    NSLog(@"History查找成功");

    return set;
}

-(void)deletLoveListWithName:(NSString *)name{
    NSString * deletSql=@"delete from lovelist where name=?";
    if ([_dataBase executeUpdate:deletSql,name ]) {
        NSLog(@"删除成功");
    }
}
-(void)updatate;
{
  NSString * updateSQL=@"update test set name=? where name=?";
    if ([_dataBase executeUpdate:updateSQL,@"",nil]) {
        NSLog(@"修改成功");
    }
    else
        NSLog(@"修改失败");

}
-(void)updataHistoryWithName:(NSString *)name num:(NSString *)number;{
    NSString * updataSQl=@"update lovelist set str=? where name=?";
    if ([ _dataBase executeUpdate:updataSQl,name,number]) {
        NSLog(@"修改成功");
    }
    else
        
NSLog(@"修改失败");



}



-(FMResultSet *)productSelectAll{
    
    NSString * selectSql=@"select * from product2";
    FMResultSet * set=[_dataBase executeQuery:selectSql];
    return set;
}

-(FMResultSet *)productSelectWithType:(NSString *)type
{
    NSString * selectSql=@"select * from product2 where type=?";
    FMResultSet * set=[_dataBase executeQuery:selectSql,type];
    return set;
}


-(FMResultSet *)subjectSelectAll{
   
    NSString * selectSql=@"select * from subject";
    FMResultSet * set=[_dataBase executeQuery:selectSql];
    return set;
}



@end
