//
//  Migration.h
//  cocopodsAndfmdb
//
//  Created by apple on 16/11/15.
//  Copyright © 2016年 ss. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "FMDBMigrationManager.h"
@interface Migration : NSObject<FMDBMigrating>

@property (nonatomic,readonly)NSString * name;//升级描述
@property (nonatomic,readonly)uint64_t version;//版本号
-(BOOL)migrateDatabase:(FMDatabase *)database error:(out NSError *__autoreleasing *)error;
-(instancetype)initWithName:(NSString *)name addVersion:(uint64_t)version andExecuteUpdateArray:(NSArray *)updateArray;//升级描述 版本号 升级语句
@end
