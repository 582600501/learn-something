//
//  Model.m
//  cocopodsAndfmdb
//
//  Created by apple on 16/11/17.
//  Copyright © 2016年 ss. All rights reserved.
//

#import "Model.h"

@implementation Model


@end
