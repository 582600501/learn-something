//
//  ViewController.m
//  cocopodsAndfmdb
//
//  Created by apple on 16/11/10.
//  Copyright © 2016年 ss. All rights reserved.
//

#import "ViewController.h"
#import "FMDataBaseManager.h"
#import "Model.h"

#define SCREENW [UIScreen mainScreen].bounds.size.width
#define SCREENH  [UIScreen mainScreen].bounds.size.height


@interface ViewController ()<UITableViewDelegate,UITableViewDataSource>
@property (nonatomic,strong)UITextField * text;
@property (nonatomic,strong)UIButton * callButton;
@property (nonatomic,strong)UITableView * tableview;
@property (nonatomic,strong)NSMutableArray * dateSource;
@property (nonatomic,strong)FMDataBaseManager * database;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _dateSource=[[NSMutableArray alloc]init];
    _database=[FMDataBaseManager shareDataBaseManager];
 //   [_database addNewField];
 //   [_database updatate];
    [self createUI];
    
    [self getHistory];
    

}
-(void)getHistory{

    FMResultSet * set=[_database selectAllFromtest];
    while ([set next]) {
        Model * model=[[Model alloc]init];
        model.callnumber=[set stringForColumn:@"callnumber"];
        if (![set stringForColumn:@"name"]) {
            
        }
        model.name=[set stringForColumn:@"name"];
        [_dateSource addObject:model];
    }

}

-(void)createUI{
    _text=[[UITextField alloc]initWithFrame:CGRectMake(SCREENW/2-90, 60, 180, 40)];
    _text.layer.borderWidth=1;
    _text.layer.borderColor=[UIColor blackColor].CGColor;
    [self.view addSubview:_text];
    
    _callButton=[[UIButton alloc]initWithFrame:CGRectMake(SCREENW/2-50, 120, 100, 40)];
    [_callButton setTitle:@"提交" forState:UIControlStateNormal];
    [_callButton setBackgroundColor:[UIColor blueColor]];
    [_callButton addTarget:self action:@selector(submit) forControlEvents:UIControlEventTouchUpInside];
    [self.view addSubview:_callButton];
    
    _tableview=[[UITableView alloc]initWithFrame:CGRectMake(0, 170, SCREENW, SCREENH-200)];
    _tableview.dataSource=self;
    _tableview.delegate=self;
    [self.view addSubview:_tableview];
    
}
-(void)submit{
    NSDate *currentDate = [NSDate date];//获取当前时间，日期
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"YYYY/MM/dd HH:mm:ss"];
    NSString *dateString = [dateFormatter stringFromDate:currentDate];
   
    _database=[FMDataBaseManager shareDataBaseManager];
    [_database insertIntoHistory:_text.text calltime:dateString];
    Model * model=[[Model alloc]init];
    model.name=dateString;
    model.callnumber=_text.text;
    [_dateSource addObject:model];
    [_tableview reloadData];
    [self.view endEditing:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return _dateSource.count;
}
// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    Model * model=_dateSource[indexPath.row];
    UITableViewCell * cell=[[UITableViewCell alloc]initWithFrame:CGRectMake(0, 0, SCREENW, 50)];
    NSString * str;
    if (!model.name) {
        str=@"";
    }
    else
        str=model.name;
    cell.textLabel.text=[NSString stringWithFormat:@"%@ %@",model.callnumber,str];

    return cell;
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    return YES;
}
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{

  return UITableViewCellEditingStyleDelete;
}

-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.row<_dateSource.count) {
        Model * model=_dateSource[indexPath.row];
        [_database deletetestWithCallNumber:model.callnumber name:model.name];
        [_dateSource removeObjectAtIndex:indexPath.row];
    }

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
                
