//
//  Model.h
//  cocopodsAndfmdb
//
//  Created by apple on 16/11/17.
//  Copyright © 2016年 ss. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Model : NSObject
@property (nonatomic,copy)NSString * name;
@property (nonatomic,copy)NSString * callnumber;
@end
