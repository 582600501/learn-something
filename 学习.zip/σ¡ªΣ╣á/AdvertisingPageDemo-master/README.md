
#app启动时的广告页demo


##[博客讲解地址](http://www.jianshu.com/p/ffa65292abf2)

![image](https://github.com/zhouhuanqiang/AdvertisingPageDemo/raw/master/resources/1.gif)

