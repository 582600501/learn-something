//
//  BidRecordListController.h
//  fanwe_p2p
//
//  Created by mac on 14-8-19.
//  Copyright (c) 2014年 mac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BidRecordListController : UIViewController

@property (strong, nonatomic) IBOutlet UITableView *myTableView;

@end
