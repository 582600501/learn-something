//
//  ViewController.m
//  changeimgcolor
//
//  Created by apple on 16/12/3.
//  Copyright © 2016年 ss. All rights reserved.
//

#import "ViewController.h"
#import "UIImage+RTTint.h"
@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIImage * img=[UIImage imageNamed:@"kc_dia_dial_num_close_no(2)"];
    [img rt_tintedImageWithColor:[UIColor colorWithRed:234/255.0 green:234/255.0 blue:234/255.0 alpha:1]];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
