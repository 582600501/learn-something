//
//  SelfHelpViewController.h
//  world
//
//  Created by apple on 16/4/19.
//  Copyright © 2016年 ss. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelfHelpViewController : UIViewController
@property (nonatomic,copy) NSArray * XBParam;
@end
