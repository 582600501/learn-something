//
//  TelPhoneBookView.h
//  callWorld
//
//  Created by apple on 16/4/19.
//  Copyright © 2016年 ss. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TelPhoneBookView : UIView

@property UITableView * tableview;

@property NSMutableArray * _dataSource;
@property NSMutableArray * _sortArray;
@property NSMutableArray * _sectionTitle;
@property NSMutableArray * _otherArray;
@property UIActivityIndicatorView * indicator;
@property UILabel * _bgLabel;
@property UIView * _shandowView;
@property UILabel * _smalllabel;

@property UIImageView * _imageview1;




@end
