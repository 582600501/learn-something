//
//  TelPhoneBookView.m
//  callWorld
//
//  Created by apple on 16/4/19.
//  Copyright © 2016年 ss. All rights reserved.
//

#import "TelPhoneBookView.h"

@implementation TelPhoneBookView

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}

-(void)setupUI{
    self.backgroundColor=[UIColor whiteColor];
    
    _tableview=[[UITableView alloc]initWithFrame:CGRectMake(0, 0,SCREENW , SCREENH-30) style:UITableViewStyleGrouped];
//    _tableview.delegate=self;
//    _tableview.dataSource=self;
    //_tableview.contentInset = UIEdgeInsetsMake(0, 0, self.tabBarController.tabBar.bounds.size.height + 13, 0);
    //    _tableview.contentInset = UIEdgeInsetsMake(0, 0, self.tabBarController.tabBar.bounds.size.height + 13, 0);
    // 设置cell分割线
    // 设置分割线没有内容边距
    _tableview.separatorInset = UIEdgeInsetsZero;
    // 清空tableView的默认布局间距
    //   _tableview.layoutMargins = UIEdgeInsetsZero;
    _tableview.showsVerticalScrollIndicator=NO;
    _tableview.backgroundColor=[UIColor redColor];
    [self addSubview:_tableview];
    
    
}









/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
