//
//  FriendViewController.h
//  world
//
//  Created by apple on 16/4/19.
//  Copyright © 2016年 ss. All rights reserved.
//

#import <UIKit/UIKit.h>


#import "TelPhoneBookView.h"


@interface FriendViewController : UIViewController
@property (nonatomic,strong)TelPhoneBookView * bookview;
@end
