//
//  People.m
//  ss2
//
//  Created by apple on 16/3/28.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "People.h"

@implementation People

@end
