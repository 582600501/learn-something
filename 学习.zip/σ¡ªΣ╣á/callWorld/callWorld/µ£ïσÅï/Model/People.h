//
//  People.h
//  ss2
//
//  Created by apple on 16/3/28.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface People : NSObject
@property NSString * Chinese;
@property NSString * Pinyin;
@property NSMutableArray * phones;
@property  NSData *imageData;

@end
