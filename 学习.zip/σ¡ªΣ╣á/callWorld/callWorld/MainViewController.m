//
//  ViewController.m
//  callWorld
//
//  Created by apple on 16/4/19.
//  Copyright © 2016年 ss. All rights reserved.
//

#import "MainViewController.h"




@interface MainViewController ()<UIScrollViewDelegate,UITableViewDelegate,UITableViewDataSource>
{
    UITableView * _tableview;


}
@end

@implementation MainViewController



-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar setHidden:YES];

}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.view.backgroundColor=[UIColor whiteColor];
    
  [self createUI];
    
}

-(void)createUI{
//    _smallScrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 20, SCREENW, 40)];
//    _smallScrollview.backgroundColor=[UIColor orangeColor];
//    [self.view addSubview:_smallScrollview];
//    
    _Mainview=[[mainview alloc]init];
    _Mainview.tableview.delegate=self;
    _Mainview.tableview.dataSource=self;
    
    _bookview=[[TelPhoneBookView alloc]initWithFrame:CGRectMake(SCREENW, 0, SCREENW, SCREENH-60)];
    [_Mainview addSubview:_bookview];
    self.view=_Mainview;
//    self.Mainview.mainScrollview.delegate=self;
    
    
    
    
       
    self.view=_Mainview;
    
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;{

    return 5;

}

// Row display. Implementers should *always* try to reuse cells by setting each cell's reuseIdentifier and querying for available reusable cells with dequeueReusableCellWithIdentifier:
// Cell gets various attributes set automatically based on table (separators) and data source (accessory views, editing controls)

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;

{
    UITableViewCell * cell=[[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil];
    
    return cell;

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
