//
//  ViewController.h
//  callWorld
//
//  Created by apple on 16/4/19.
//  Copyright © 2016年 ss. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "mainview.h"
#import "TelPhoneBookView.h"

@interface MainViewController : UIViewController
@property (nonatomic, strong) mainview * Mainview;
@property (nonatomic,strong)TelPhoneBookView * bookview;
@end

