//
//  mainview.h
//  callWorld
//
//  Created by apple on 16/4/19.
//  Copyright © 2016年 ss. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mainview : UIView


@property (nonatomic,strong)    UIScrollView * smallScrollview;
@property  (nonatomic,strong)   UIScrollView * mainScrollview;
@property (nonatomic,strong) UIButton * phoneButton;
@property (nonatomic,strong) UIButton * friendButton;
@property (nonatomic,strong) UIButton * selfhelpButton;
@property (nonatomic,strong) UIButton * marketButton;
@property (nonatomic,strong) UIButton * myButton;

@property (nonatomic,strong) UITableView * tableview;

@end
