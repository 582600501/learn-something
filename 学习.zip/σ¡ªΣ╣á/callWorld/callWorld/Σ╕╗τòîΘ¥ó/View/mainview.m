//
//  mainview.m
//  callWorld
//
//  Created by apple on 16/4/19.
//  Copyright © 2016年 ss. All rights reserved.
//

#import "mainview.h"

@implementation mainview

- (instancetype)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self setupUI];
    }
    return self;
}

-(void)setupUI{
    self.backgroundColor=[UIColor whiteColor];

//    _smallScrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 20, SCREENW, 40)];
//    _smallScrollview.backgroundColor=[UIColor orangeColor];
    [self addSubview:self.smallScrollview];
    
//    _mainScrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 20, SCREENW, SCREENH-60)];
//    _mainScrollview.backgroundColor=[UIColor grayColor];
//    _mainScrollview.pagingEnabled=YES;
//    _mainScrollview.contentSize=CGSizeMake(SCREENW*5, SCREENH-60);
    [self addSubview:self.mainScrollview];


}

-(UIScrollView *)smallScrollview{

    if (_smallScrollview==nil) {
        _smallScrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 20, SCREENW, 40)];
        _smallScrollview.backgroundColor=[UIColor orangeColor];
        
//        @property (nonatomic,strong) UIButton * phoneButton;
//        @property (nonatomic,strong) UIButton * friendButton;
//        @property (nonatomic,strong) UIButton * selfhelpButton;
//        @property (nonatomic,strong) UIButton * marketButton;
//        @property (nonatomic,strong) UIButton * myButton;
        _phoneButton=[[UIButton alloc]initWithFrame:CGRectMake(0, -20, SCREENW/5, 40)];
        [_phoneButton setTitle:@"拨号" forState:UIControlStateNormal];
        [_smallScrollview addSubview:_phoneButton];
        
        _friendButton=[[UIButton alloc]initWithFrame:CGRectMake(SCREENW/5, -20, SCREENW/5, 40)];
        [_friendButton setTitle:@"朋友" forState:UIControlStateNormal];
        [_smallScrollview addSubview:_friendButton];
        
        _selfhelpButton=[[UIButton alloc]initWithFrame:CGRectMake(SCREENW/5*2, -20, SCREENW/5, 40)];
        [_selfhelpButton setTitle:@"自助" forState:UIControlStateNormal];
        [_smallScrollview addSubview:_selfhelpButton];
        
        _marketButton=[[UIButton alloc]initWithFrame:CGRectMake(SCREENW/5*3, -20, SCREENW/5, 40)];
        [_marketButton setTitle:@"商城" forState:UIControlStateNormal];
        [_smallScrollview addSubview:_marketButton];
        
        _myButton=[[UIButton alloc]initWithFrame:CGRectMake(SCREENW/5*4, -20, SCREENW/5, 40)];
        [_myButton setTitle:@"额度" forState:UIControlStateNormal];
        [_smallScrollview addSubview:_myButton];

    }
    return _smallScrollview;
}

 -(UIScrollView *)mainScrollview{
     if (_mainScrollview==nil) {
         _mainScrollview=[[UIScrollView alloc]initWithFrame:CGRectMake(0, 60, SCREENW, SCREENH-60)];
         _mainScrollview.backgroundColor=[UIColor grayColor];
         _mainScrollview.pagingEnabled=YES;
         _mainScrollview.contentSize=CGSizeMake(SCREENW*5, SCREENH-60);
         _tableview=[[UITableView alloc]initWithFrame:CGRectMake(SCREENW, 0,SCREENW , SCREENH-60) style:UITableViewStyleGrouped];
         //    _tableview.delegate=self;
         //    _tableview.dataSource=self;
         //_tableview.contentInset = UIEdgeInsetsMake(0, 0, self.tabBarController.tabBar.bounds.size.height + 13, 0);
         //    _tableview.contentInset = UIEdgeInsetsMake(0, 0, self.tabBarController.tabBar.bounds.size.height + 13, 0);
         // 设置cell分割线
         // 设置分割线没有内容边距
         _tableview.separatorInset = UIEdgeInsetsZero;
         // 清空tableView的默认布局间距
         //   _tableview.layoutMargins = UIEdgeInsetsZero;
         _tableview.showsVerticalScrollIndicator=NO;
         _tableview.backgroundColor=[UIColor redColor];
         [self addSubview:_tableview];

     }
     return _mainScrollview;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
