//
//  ViewController.h
//  foo
//
//  Created by ZTELiuyw on 16/2/14.
//  Copyright © 2016年 liuyanwei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "LYWUser.h"
#import "ViewController1.h"


@interface ViewController : UIViewController

 

//标准
@property (nonatomic,strong) LYWUser *liu;

@end

