//
//  AppDelegate.h
//  foo
//
//  Created by ZTELiuyw on 16/2/14.
//  Copyright © 2016年 liuyanwei. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

