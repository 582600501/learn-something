//
//  BeCentraliewController.h
//  BleDemo
//
//  Created by ZTELiuyw on 15/9/7.
//  Copyright (c) 2015年 liuyanwei. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreBluetooth/CoreBluetooth.h>

@interface BeCentralVewController : UIViewController<CBCentralManagerDelegate,CBPeripheralDelegate>



@end