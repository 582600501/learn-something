//
//  Person.m
//  test
//
//  Created by xuanyan.lyw on 16/4/1.
//  Copyright © 2016年 xuanyan.lyw. All rights reserved.
//

#import "Person.h"

@implementation Person

-(NSString *)whatYouName {
    return @"my name is liuyanwei";
}

-(NSString *)name {
    return @"liuyanwei";
}

@end
