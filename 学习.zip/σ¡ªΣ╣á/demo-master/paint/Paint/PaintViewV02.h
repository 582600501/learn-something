//
//  PaintView.h
//  Paint
//
//  Created by 刘彦玮 on 15/7/26.
//  Copyright (c) 2015年 刘彦玮. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PaintStep.h"

@interface PaintViewV02 : UIView



@end

