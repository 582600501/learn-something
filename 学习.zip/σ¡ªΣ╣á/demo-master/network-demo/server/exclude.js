module.exports = function(path){
	if(path=="/favicon.ico"){
		return true;
	}
	return false;
};