//
//  Download_and_upload_ViewController.h
//  network-demo
//
//  Created by 刘彦玮 on 16/2/11.
//  Copyright © 2016年 刘彦玮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Download_and_upload_ViewController : UIViewController<NSURLConnectionDataDelegate>

@end
