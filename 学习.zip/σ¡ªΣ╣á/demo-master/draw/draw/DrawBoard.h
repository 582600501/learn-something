//
//  ContrlView.h
//  draw
//
//  Created by 刘彦玮 on 15/7/23.
//  Copyright (c) 2015年 刘彦玮. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DrawBoard : UIControl


@end
